import type { FC, ReactNode } from 'react';
import type { Breakpoint, GapSize, GapSizes } from '../../types';
export interface IColumns {
    /**
     * Child Columns to render in the Columns container.<br />
     * <code>IColumn</code>
     * <pre>
     * interface IColumn {
     *   children?: ReactNode
     *   content?: boolean
     *   fractionSize?: FractionSize | FractionSizes | Array<FractionSize | FractionSizes>
     *   fractionSizeOffset?: FractionSize | FractionSizes | Array<FractionSize | FractionSizes>
     *   hiddenTouch?: boolean
     *   numericSize?: NumericSize | NumericSizes | Array<NumericSize | NumericSizes>
     *   numericSizeOffset?: NumericSize | NumericSizes | Array<NumericSize | NumericSizes>
     *   narrow?: boolean | BreakpointColumn[]
     *   textPosition?: TextPosition | TextPositions | Array<TextPosition | TextPositions>
     * }
     * </pre>
     */
    children: ReactNode;
    /** Optional Breakpoint to force columns to render at. */
    breakpoint?: Extract<Breakpoint, 'mobile' | 'desktop'>;
    /** Optional setting for Centered Column content. */
    centered?: boolean;
    /** Optional setting for specific gap settings on Columns. */
    gapSize?: GapSize | Array<GapSize | GapSizes>;
    /** Optional setting to remove Column gaps. */
    gapless?: boolean;
    /** Optional setting to enable mobile stacking. */
    mobile?: boolean;
    /** Optional setting to enable Multiline Column content. */
    multiline?: boolean;
    /** Optional setting to enable vertical alignment of Columns. */
    vcentered?: boolean;
}
/**
 * <strong>NOTE:</strong> Columns should only contain Column children!
 */
declare const Columns: FC<IColumns>;
export default Columns;
